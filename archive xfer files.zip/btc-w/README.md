# btc-w | a basic Bitcoin wallet
![ss1](btcw.png)
# built with ChatGPT4
# segwit.py only ! hdlegacy.py broken